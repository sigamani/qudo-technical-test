import pandas as pd
import numpy as np


def drop_na_cols(df, perc_missing=0.7) -> pd.DataFrame:
    """Drop any columns with X% of the data missing or unanswered.
    INPUTS:
    df      dataframe of clean survey data
    perc_missing    threshold of missing values for removing a column, i.e. if 0.7=70% missing or more, then remove.
    """
    non_nan = df.shape[0] * (1 - perc_missing)
    for col in df.columns:
        df[col].replace(' ', np.nan, inplace = True)
    result = df.dropna(axis = 1, thresh = non_nan)
    return result


def drop_pointless_cols(df) -> pd.DataFrame:
    """ Drop columns where there are more than 20 unique responses, or only one identical response."""
    result = df
    for col in df.columns:
        if len(df[col].unique()) == 1 or len(df[col].unique()) > 20:
            result = result.drop(col, axis = 1)
    return result


def clean_up(df):
    clean_df = df.replace('nan', np.nan)
    clean_df = drop_na_cols(clean_df, 0.7)
    clean_df = drop_pointless_cols(clean_df)
    clean_df = clean_df.replace(np.nan, "-99")
    dropped_cols = set(df.columns).symmetric_difference(clean_df.columns)
    print("\nData has been prepared for clustering.\n")
    return clean_df, dropped_cols
