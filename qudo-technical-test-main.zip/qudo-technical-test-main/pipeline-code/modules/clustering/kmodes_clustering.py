import pandas as pd
import numpy as np
from numpy import matlib
from joblib import Parallel, delayed
from tqdm import tqdm
from kmodes.kmodes import KModes
from modules.clustering.process import clean_up
import warnings

# ------------- KModes ------------------

def kmodes_cost(num_clusters, df, verbose_binary):
    """Identify optimal number of clusters"""
    print(f"Starting kmodes_cost function {num_clusters}...")
    kmode = KModes(n_clusters = num_clusters, init = "Cao", n_init = 1, verbose = verbose_binary)
    kmode.fit_predict(df)
    print(f"For {num_clusters} clusters, cost = {kmode.cost_}")
    return kmode.cost_


def optimal_clusters(df, k_min, k_max, k_increment):
    """ Fn to optimise number of clusters to be used, k, by optimising cost (i.e. minimising euclidian dist).
    k_min must be >=1, k_increment must be integer."""

    # Calc cost fn
    num_cores = 12  # multiprocessing.cpu_count()
    inputs = tqdm(list(range(k_min, k_max, k_increment)))
    cost = Parallel(n_jobs = num_cores)(delayed(kmodes_cost)(i, df=df, verbose_binary = 0) for i in inputs)

    # Find the elbow
    n_points = len(cost)
    all_coord = np.vstack((range(n_points), cost)).T
    #     np.array([range(n_points), cost])
    first_point = all_coord[0]
    line_vec = all_coord[-1] - all_coord[0]
    line_vec_norm = line_vec / np.sqrt(np.sum(line_vec ** 2))
    vec_from_first = all_coord - first_point
    scalar_product = np.sum(vec_from_first * matlib.repmat(line_vec_norm, n_points, 1), axis = 1)
    vec_from_first_parallel = np.outer(scalar_product, line_vec_norm)
    vec_to_line = vec_from_first - vec_from_first_parallel
    dist_to_line = np.sqrt(np.sum(vec_to_line ** 2, axis = 1))
    idx_of_best_point = np.argmax(dist_to_line)

    y = np.array([i for i in range(k_min, k_max, 1)])
    # optimal k
    n_clusters = y[idx_of_best_point]

    return n_clusters


def execute_kmodes(df, num_clusters, cluster_vars, verbose_binary=1):
    """Executes KModes clustering
    cluster_vars: list, allows clustering on a defined columns only, or set to 'All' (str)
    num_clusters: numeric, number of clusters / output from optimal_clusters fn
    encoding_df: df, from which labels of categorical vars were encoded to numerics, in label_encode_df fn
    """
    # warnings.simplefilter(action = 'ignore', category = FutureWarning)
    # Using K-modes using Cao initialisation
    km_cao = KModes(n_clusters = num_clusters, init = "Cao", n_init = 1, verbose = verbose_binary)
    if cluster_vars == 'all':
        cluster_model = km_cao.fit(df)
    elif cluster_vars:
        print("\nCluster Variables are bespoke \n")
        cluster_model = km_cao.fit(df[cluster_vars])
    else:
        cluster_model = km_cao.fit(df)

    # Return original df with cluster labels
    clustered_df = df.copy()
    clustered_df['cluster'] = cluster_model.labels_ + 1

    return cluster_model, clustered_df


def cluster_sizes(df):
    for i in sorted(df.cluster.unique()):
        length = len(df[df.cluster == i])
        perc = round(len(df[df.cluster == i]) / len(df) * 100, 0)
        print(f"Cluster {i} length: {length} \nCluster {i} percentage: {perc}% \n")


# ------------- AUTO CLUSTERING: Analysis & Modelling ------------------

def set_up_and_cluster(df, cluster_vars='all', override_n_clusters=None):

    # Calc optimal number of clusters
    n_optimal_clusters = optimal_clusters(df=df, k_min=1, k_max=10, k_increment=1)
    n_clusters = override_n_clusters if override_n_clusters else n_optimal_clusters
    print(f"No. clusters used: {n_clusters} (override: {override_n_clusters})")

    #  Run kmodes clustering on the dataset
    cluster_model, clustered_df = execute_kmodes(df,
                                                 cluster_vars=cluster_vars,
                                                 num_clusters=n_clusters,
                                                 verbose_binary=1)
    print("\nClustering is complete.\n")
    return cluster_sizes(clustered_df), clustered_df


def return_full_clustered_df(clustered_df, processed_df, removed_cols):
    """Re-attaches columns which were removed in pre-clustering cleaning steps."""
    data = pd.concat([clustered_df, processed_df[removed_cols]], axis = 1, ignore_index = False)
    print("\nRemoved columns (from cleaning step) have been re-atached to the clustered dataframe.\n")
    return data


if __name__ == '__main__':
    # Read in data
    processed_df = pd.read_csv("../../data/processed_data/response_data/processed_lpg_responses.csv")
    print("Data upload successful.")

    # Run analysis
    clustering_data, removed_cols = clean_up(processed_df)
    cluster_sizes, clustered_df = set_up_and_cluster(clustering_data, cluster_vars='all', override_n_clusters=None)
    full_clustered_df = return_full_clustered_df(clustered_df, processed_df, removed_cols)

    print("Writing full clustered data to file...")
    full_clustered_df.to_csv("../../data/processed_data/response_data/clustered_lpg_responses.csv", index=False)

    print("FINISHED")
