import pandas as pd


def cluster_sizes(df):
    for i in sorted(df.cluster.unique()):
        length = len(df[df.cluster == i])
        perc = round(len(df[df.cluster == i]) / len(df) * 100, 0)
        print(f"Cluster {i} length: {length} \nCluster {i} percentage: {perc}% \n")


def segmentation(df, segmentation_cols):
    """Segments the data based on the columns provided. Suitable for single column or multilevel.

    INPUTS:
    df                  DataFrame, preprocessed survey results
    segmentation_cols   list type, with column or columns to be used for segmentation

    OUTPUT:
    df                  segmented dataframe, containing 'cluster' column
    """
    for col in segmentation_cols:
        df[col] = df[col].astype('str').replace(" ", "None selected")
    df['cluster'] = df[segmentation_cols].agg(' + '.join, axis=1)

    print(cluster_sizes(df))

    return df


if __name__ == '__main__':
    data = pd.read_csv("../../data/processed_data/response_data/processed_lpg_responses.csv")
    print("Data upload successful.")

    seg_cols = ['Go City:AIDA_WW_ABA_IMS_07062021', 'DEM_WW_GENDER_RB_L_v3_14072020']
    segmented_df = segmentation(data, seg_cols)
    print(segmented_df['cluster'].head())
