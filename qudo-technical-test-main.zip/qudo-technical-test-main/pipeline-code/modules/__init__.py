# ignore this line - it has been inserted for the purpose of merge request/code review
from modules.paths import Paths

paths = Paths()
