import numpy as np
import pandas as pd
import statistics
from scipy.stats import chi2_contingency
# from kmodes_clustering import *

"""This workflow works with encoded as well as unencoded data, for auto-clustered or rules-based segmentation. 
See the main function or the ipynb for a demo."""


class SalientQuestions:
    def __init__(self, clustered_df_):
        self.df = clustered_df_
        self.summary_stats = None

    def var_significance_chi2(self, q_code, seg_col='cluster', alpha=0.05):
        """
        We answer the question, "Are the clusters contingent on the responses of this survey question?".

        H0, null hypothesis: Responses are distributed identically across cluster groups.
        H1, alternative hypothesis: Answers to this question differ, based on cluster group.

        The variables are considered *independent* (FTRH0) if the observed and expected frequencies of responses
        (from contingency table) are similar, else, we can conclude that there's evidence to suggest that the clusters
        are statistically significantly *dependant* / *related* (Reject H0) on the results of that particular question.
        """

        # Calc contingency table, test stat and p value
        contingency_table = pd.crosstab(self.df[q_code], self.df[seg_col])
        chi_2, p_val, dof, expected = chi2_contingency(contingency_table)

        if p_val < alpha:
            # print(f"Evidence to reject H0 at {alpha} level - THIS VARIABLE IS SIGNIFICANT.")
            return round(p_val, 4)
        else:
            # print(f"FTR H0 at {alpha} level:'(")
            return np.nan

    def targeting_segment(self, q_code, seg_col, verbose=False):
        """Identifies which segment should use the specified question for targeting.

        Calculated based on the maximum difference answer choice, versus the population.
        """
        # Create % answers grid for the Q & extract cluster %
        perc_diff_matrix = []
        ans_options = self.df[q_code].unique()

        for i, val in enumerate(ans_options):
            pop_ans_perc = self.df[q_code][self.df[q_code] == val].count() / self.df[
                q_code].count()
            # Calculate the percentage of answer i, for each segment..
            seg_ans_perc = self.df.groupby([seg_col])[q_code].apply(
                lambda x: round((x == val).sum() / len(x) * 100, 1)).rename_axis(['ans_' + str(i)])
            # ..then subtract the population percentage of ans i, and extract max difference column.
            seg_ans_perc_diff_to_pop = round(seg_ans_perc - pop_ans_perc, 1)
            # This is used to identify the segment which is most dissimilar to the population, for fb/ggl targeting
            perc_diff_matrix.append(seg_ans_perc_diff_to_pop)

        # Return segment for targeting
        perc_diff_matrix_np = np.array(perc_diff_matrix)
        ind = np.unravel_index(np.argmax(perc_diff_matrix_np, axis = None), perc_diff_matrix_np.shape)
        # Get segment name from group_by index (to be exactly mirroring for loop)
        targeting_seg = self.df.groupby([seg_col])[seg_col].count().index[ind[1]]

        print(
            f"RESULTS:\nAnswer: {ind[0]} - {ans_options[ind[0]]}, \nSegment: {targeting_seg}") if verbose else None
        return targeting_seg

    def deliver_stats(self, q_code, seg_col='cluster'):

        """
        DELIVER STATISTICS
        Input:   Define the q_code & output from the KModes algo. **applies to subset not df component of class**
        Output:  Returns the mode, overall response rate, % of modal responses in the entire survey,
        & the chi-2 result
        """
        self.df = self.df.replace(' ', np.nan)
        n_seg = len(self.df[seg_col].unique())

        # Calc mode & overall response rate
        pop_mode = statistics.mode(self.df.loc[:, q_code])
        response_rate = self.df[q_code].count() / len(self.df[q_code]) * 100

        # Identify the segment which should use this feature for targeting
        targeting_seg = self.targeting_segment(q_code = q_code, seg_col = seg_col)

        col_dct = {i + 1: 'cluster_' + str(i + 1) for i in range(n_seg)}
        col_dct['index'] = 'ans_val'

        # Calculate % of modal answer in entire survey
        mode_pop_perc = round(self.df[q_code].value_counts()[pop_mode] / self.df[q_code].count() * 100, 1)

        # Apply Chi-2 test to decide if significant variable
        chi_2_result = self.var_significance_chi2(q_code, seg_col)

        return pop_mode, response_rate, mode_pop_perc, chi_2_result, targeting_seg

    def create_summary_stats_df(self, seg_col='cluster'):
        """
        DISCOVER & DELIVER PAGE STATISTICS.

        Accepts: self &  segmentation column (auto or rules based)
        Returns: Analysis table, sorted by the top n most extreme p_values

        Logic - 1. ranks questions by chi-2 test p value (smallest to largest)
                2. identifies imbalances in Q responses, across segments to identify which segment should use
                    each question for targeting (1-1)
        """
        deliver_stats_dct = {'q_code': [], 'pop_mode': [], 'response_rate': [], 'mode_pop_perc': [],
                             'chi_2_result': [], 'targeting_seg': []}

        for q_code in self.df.columns:
            if q_code == seg_col:
                pass
            else:
                try:
                    pop_mode, response_rate, mode_pop_perc, chi_2_result, targeting_seg = self.deliver_stats(
                        q_code = q_code,
                        seg_col = seg_col)
                    deliver_stats_dct['q_code'].append(q_code)
                    deliver_stats_dct['pop_mode'].append(pop_mode)
                    deliver_stats_dct['response_rate'].append(response_rate)
                    deliver_stats_dct['mode_pop_perc'].append(mode_pop_perc)
                    deliver_stats_dct['chi_2_result'].append(chi_2_result)
                    deliver_stats_dct['targeting_seg'].append(targeting_seg)
                except:
                    pass

        summary_stats_df = pd.DataFrame(deliver_stats_dct).sort_values('chi_2_result')
        self.summary_stats = summary_stats_df

        return summary_stats_df


if __name__ == '__main__':
    # Load data
    clustered_df = pd.read_csv('../data/lpg_clustered_df.csv', dtype = 'str')

    # Create instance
    salient_feats = SalientQuestions(clustered_df)
    # Calc discover & deliver stats: seg_col= 'cluster' for auto clustering or 'question_code' for rules based
    salient_feats.create_summary_stats_df(seg_col = 'DEM_WW_AGE_DM_L_v1_14072020')
    print(f"SUMMARY STATS ~ /n {salient_feats.summary_stats}")

    print("Writing summary stats file to disk...")
    salient_feats.summary_stats.to_csv("../data/lpg_summary_stats.csv")
    print('FINISHED')
