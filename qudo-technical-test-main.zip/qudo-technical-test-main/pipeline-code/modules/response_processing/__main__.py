# for pipeline use only input in terminal: python -m modules.response_processing

import pandas as pd
from modules.response_processing import load_data, clean_data, add_weights, save_to_output
from datetime import date

# Define today
today = date.today()
date_str = today.strftime("%b-%d-%Y")

# Load data
response_data = load_data.response_data(id_column='ID')  # Response ID or ID column

# Clean data
response_data = clean_data.main(df=response_data)

# Add weights
response_data = add_weights.main(data=response_data,
                                 gender_col="DEM_WW_GENDER_RB_L_v3_14072020",
                                 age_col="DEM_WW_AGE_DM_L_v1_14072020",
                                 region_col="REGION")

# Save data
save_to_output.processed_responses(data=response_data,
                                   file_name=f'processed_responses_{date_str}.csv')
