from os import listdir
import pandas as pd


def response_data(id_column: str) -> pd.DataFrame:
    """
    :return:
    """
    # detect all files in input directory
    raw_path = 'data/raw_data/response_data'  # - when running from terminal / root directory
    csv_files = [file for file in listdir(raw_path) if file.endswith('.csv')]

    # loading all files
    print(f"\nLoading survey response data from {raw_path} directory...\n")
    df_list = []
    for file in csv_files:
        file_name = file.replace(' ', '_').split('.csv')[0]
        globals()[f'table_{file_name}'] = pd.read_csv(raw_path + '/' + file)
        df_list.append(globals()[f'table_{file_name}'])
        del globals()[f'table_{file_name}']
        print(f'    - {file} loaded ...')

    print('\n')

    # concatenate all files
    data = pd.concat(df_list, axis=0)

    # check for duplicates within file based on id_column variable passed to function
    print('Check duplications within response data ...\n')
    if data[id_column].nunique() != data.shape[0]:
        print(f'     - Duplicates were detected in {id_column} column! Dropping duplicates and keeping first ...\n')
        data = data.drop_duplicates(subset=id_column, keep='first')
    else:
        print(f"     - No duplicates detected in {id_column} column.\n")

    return data



