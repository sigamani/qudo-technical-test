from pathlib import Path
import pandas as pd


def processed_responses(data: pd.DataFrame, file_name: str):
    print("Saving processed response data to output directory...\n")

    out_dir = 'data/processed_data/response_data'  # when running in terminal / root directory

    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    file_name = file_name.replace(' ', '_')
    file_name = file_name.replace('-', '_')

    data.to_csv(f"{out_dir}/{file_name}", index=False)

    print(f"     - Response data saved to output directory: {out_dir}")

