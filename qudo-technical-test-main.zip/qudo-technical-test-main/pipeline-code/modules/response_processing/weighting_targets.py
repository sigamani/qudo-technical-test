# weighting targets for each country - this will be in database some day and collected from there

def weighting_targets(gender_col: str, age_col: str, region_col: str) -> dict:
    targets = {
        'USA': [
            {
                # GENDER
                f"{gender_col}": {
                    "Male": 49.23,  # 49.23%
                    "Female": 50.77,  # 50.77%
                }
            },
            {
                # AGE
                f"{age_col}": {
                    "18-24": 11.9,  # 11.9%
                    "25-34": 17.85,  # 17.85%
                    "35-44": 16.42,  # 16.42%
                    "45-54": 16.01,  # 16.01%
                    "55-64": 16.64,  # 16.64%
                    "65 and above": 21.18,  # 21.18%
                }
            },
            {
                # REGION
                f"{region_col}": {
                    "Midwest": 20.82,  # 20.82%
                    "Northeast": 17.06,  # 17.06%
                    "South": 38.26,  # 38.26%
                    "West": 23.86,  # 23.87%
                }
            },
        ],

        'UK': [
            {
                # GENDER
                f"{gender_col}": {
                    "Male": 0.0,
                    "Female": 0.0,
                }
            },
            {
                # AGE
                f"{age_col}": {
                    "18-24": 0.0,
                    "25-34": 0.0,
                    "35-44": 0.0,
                    "45-54": 0.0,
                    "55-64": 0.0,
                    "65 and above": 0.0,
                }
            },
            {
                # REGION
                f"{region_col}": {
                    "X": 0.0,
                    "Y": 0.0,
                    "Z": 0.0,
                    "ZZ": 0.0,
                }
            },
        ],
    }

    return targets
