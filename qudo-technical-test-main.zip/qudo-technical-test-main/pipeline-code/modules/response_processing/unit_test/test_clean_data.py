# this script could test only functions within the clean_data script
import pandas as pd
from modules.response_processing.clean_data import *

test_data = pd.read_csv('data/test_data/survey-results-19-08-21.csv')


def test_drop_missing_ID_respondents():
    if test_data.ID.isna().sum() != 0:
        amended_data = drop_missing_ID_respondents(test_data)
        assert amended_data.shape[0] < test_data.shape[0]
    else:
        amended_data = drop_missing_ID_respondents(test_data)
        assert amended_data.shape[0] == test_data.shape[0]
